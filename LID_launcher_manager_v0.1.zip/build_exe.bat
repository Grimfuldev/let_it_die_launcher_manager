echo off
setlocal
cd /d "%~dp0"

set APP_NAME=LetItDieExecute
set SCRIPT=letitdie_execute.py
if not exist "%SCRIPT%" if exist "Let it Die Execute.py" set SCRIPT=Let it Die Execute.py
set ICON_ICO=UI_Assets\Lidico.ico
if not exist "%ICON_ICO%" if exist "UI_Assets\lidico.ico" set ICON_ICO=UI_Assets\lidico.ico

if not exist "%SCRIPT%" (
  echo Missing letitdie_execute.py - put this .bat next to it.
  goto :fail
)
if not exist "%ICON_ICO%" (
  echo Missing UI_Assets\Lidico.ico - the exe would get the default Python icon.
  goto :fail
)
if not exist "UI_Assets\UI background.webp" echo Warning: UI_Assets\UI background.webp not found - plain dark background.
if not exist "UI_Assets\uncle glasses ready.webp" echo Warning: UI_Assets\uncle glasses ready.webp not found - no title icon.
if not exist "UI_Assets\let it die cursor.webp" echo Warning: UI_Assets\let it die cursor.webp not found - normal cursor.

echo.
echo === Installing build requirements ===
python -m pip install --upgrade pip pyinstaller pillow
if errorlevel 1 goto :fail

echo.
echo === Building %APP_NAME%.exe ===
python -m PyInstaller --noconfirm --clean --onefile --windowed ^
  --name "%APP_NAME%" ^
  --icon "%ICON_ICO%" ^
  --add-data "UI_Assets;UI_Assets" ^
  --hidden-import PIL ^
  --hidden-import PIL.Image ^
  --hidden-import PIL.ImageTk ^
  "%SCRIPT%"
if errorlevel 1 goto :fail

echo.
echo Built: dist\%APP_NAME%.exe
echo UI_Assets are packed inside the exe.
echo settings.ini and EXEs.json are written next to the exe.
echo grace_time, start_minimized, disable_shortcut and wait_between_launches
echo are edited in settings.ini.
pause
exit /b 0

:fail
echo.
echo Build failed - see the messages above.
pause
exit /b 1